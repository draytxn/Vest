var AUTH0_CLIENT_ID='6F2tSX1tlcvyWWHiWXb4dosMXh2T6mFp';
var AUTH0_CALLBACK_URL="http://localhost:8100 ";
var AUTH0_DOMAIN='vest1.auth0.com';
